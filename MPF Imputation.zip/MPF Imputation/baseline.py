import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error

# ========== 读取数据 ==========
df = pd.read_csv("mpf_simulation_output.csv")
T = 1
vehicle_ids = [0, 1, 2, 3]
vel_cols = [f"velocity_{i}" for i in vehicle_ids]
spc_cols = [f"spacing_{i}" for i in vehicle_ids]

velocity = df[vel_cols].values
spacing = df[spc_cols].values
target_velocity = df["velocity_4"].values
target_spacing = df["spacing_4"].values

# ========== 缺失模拟（0–3车辆） ==========
def simulate_missing(data, rate=0.90):
    mask = ~np.isnan(data)
    for i in range(data.shape[1]):
        for t in range(T, len(data)):
            if np.random.rand() < rate:
                data[t, i] = np.nan
                mask[t, i] = False
    return data, mask

velocity_missing, mask_v = simulate_missing(velocity.copy())
spacing_missing, mask_s = simulate_missing(spacing.copy())

# ========== 插值补全函数（peer + time） ==========
def interpolate_feature(v_missing, s_missing, m_v, m_s, t):
    v_t = v_missing[t - T + 1:t + 1]
    s_t = s_missing[t - T + 1:t + 1]
    x = np.stack([v_t, s_t], axis=-1)  # [T, 4, 2]
    m = np.stack([m_v[t - T + 1:t + 1], m_s[t - T + 1:t + 1]], axis=-1)

    for i in range(T):
        for j in range(4):
            for k in range(2):
                if not m[i, j, k]:
                    peer_vals = x[i, :, k][m[i, :, k]]
                    x[i, j, k] = np.mean(peer_vals) if len(peer_vals) > 0 else 0.0
    return x

# ========== 预测目标车辆4（均值策略） ==========
pred_velocity = []
pred_spacing = []

for t in range(T, len(df)):
    x = interpolate_feature(velocity_missing, spacing_missing, mask_v, mask_s, t)
    # 均值预测策略
    v4_pred = np.mean(x[:, :, 0])
    s4_pred = np.mean(x[:, :, 1])
    pred_velocity.append(v4_pred)
    pred_spacing.append(s4_pred)

# ========== 存储预测结果为新CSV ==========
df_out = df.copy()

# 替换从 T 开始的 velocity_4 和 spacing_4
df_out.loc[T:, "velocity_4"] = pred_velocity
df_out.loc[T:, "spacing_4"] = pred_spacing

# 保存完整文件
df_out.to_csv("baseline_90%missing_complete.csv", index=False)
print("✅ Saved to baseline_90%missing_complete.csv (前5帧保留原值)")

# ========== 评估 =========
changed_mask_velocity = df["velocity_4"].values[T:] != pred_velocity
changed_mask_spacing = df["spacing_4"].values[T:] != pred_spacing

pred_velocity = np.array(pred_velocity)
pred_spacing = np.array(pred_spacing)

def compute_mse_filtered(y_true, y_pred, mask):
    return mean_squared_error(y_true[mask], y_pred[mask])

def compute_mae_filtered(y_true, y_pred, mask):
    return np.mean(np.abs(y_true[mask] - y_pred[mask]))

print("===== Baseline Predict CAV4 (changed only) =====")
print(f"Velocity MSE (changed only): {compute_mse_filtered(target_velocity[T:], pred_velocity, changed_mask_velocity):.4f}")
print(f"Spacing  MSE (changed only): {compute_mse_filtered(target_spacing[T:], pred_spacing, changed_mask_spacing):.4f}")
print(f"Velocity MAE (changed only): {compute_mae_filtered(target_velocity[T:], pred_velocity, changed_mask_velocity):.4f}")
print(f"Spacing  MAE (changed only): {compute_mae_filtered(target_spacing[T:], pred_spacing, changed_mask_spacing):.4f}")
