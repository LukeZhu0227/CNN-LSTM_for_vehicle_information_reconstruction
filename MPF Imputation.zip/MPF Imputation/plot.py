import matplotlib.pyplot as plt

missing_rates = [10, 20, 30, 40, 50, 60, 70, 80, 90]

# Original Framework Reference Values
original_ttc = 5.77
original_std = 5.25
original_speed = 20.29

# Average TTC
avg_ttc = {
    "Statistical Mean": [10.00, 9.97, 9.87, 9.65, 9.38, 8.45, 7.09, 5.92, 3.17],
    "Transformer": [6.33, 6.97, 8.06, 8.11, 7.67, 7.00, 5.75, 4.02, 2.72],
    "CNN-LSTM": [6.23, 6.15, 6.23, 6.35, 6.32, 6.44, 6.64, 6.42, 6.45]
}

# Velocity Standard Deviation
velocity_std = {
    "Statistical Mean": [1.69, 1.94, 2.48, 3.31, 5.17, 7.24, 8.80, 10.05, 9.81],
    "Transformer": [4.56, 3.83, 3.12, 2.87, 3.10, 3.11, 3.02, 2.42, 2.14],
    "CNN-LSTM": [4.98, 4.93, 5.00, 5.07, 4.77, 4.95, 5.02, 4.21, 4.74]
}

# Average Speed
avg_speed = {
    "Statistical Mean": [20.25, 20.21, 20.08, 19.85, 19.02, 17.41, 15.34, 11.76, 7.18],
    "Transformer": [20.37, 20.32, 20.08, 20.66, 20.03, 20.45, 20.80, 20.67, 19.63],
    "CNN-LSTM": [20.00, 20.01, 20.08, 19.82, 20.12, 19.95, 20.34, 20.29, 19.24]
}

# Color and style maps
color_map = {
    "CNN-LSTM": "blue",
    "Transformer": "green",
    "Statistical Mean": "orange"
}
linestyle_map = {
    "CNN-LSTM": "-",
    "Transformer": "-.",
    "Statistical Mean": "--"
}
marker_map = {
    "CNN-LSTM": "^",
    "Transformer": "s",
    "Statistical Mean": "o"
}

# Plot function
def plot_metric(data_dict, ylabel, title, reference_value):
    plt.figure(figsize=(8, 5))
    for model in data_dict:
        plt.plot(
            missing_rates,
            data_dict[model],
            label=model,
            color=color_map[model],
            linestyle=linestyle_map[model],
            marker=marker_map[model]
        )
    plt.axhline(y=reference_value, color='gray', linestyle=':', linewidth=1.5, label='Original Framework')
    plt.xlabel("Missing Rate (%)")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()

# Example usage
plot_metric(avg_ttc, "Average TTC (s)", "Average TTC under Different Missing Rates", original_ttc)
plot_metric(velocity_std, "Velocity Standard Deviation", "Velocity Standard Deviation under Different Missing Rates", original_std)
plot_metric(avg_speed, "Average Speed (m/s)", "Average Speed under Different Missing Rates", original_speed)