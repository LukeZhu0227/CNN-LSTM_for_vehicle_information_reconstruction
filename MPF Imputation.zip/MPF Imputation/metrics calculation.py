import pandas as pd
import numpy as np

# 读取仿真数据文件
file_path = "cnn_70%missing_complete.csv"  # 替换为你的实际路径
df = pd.read_csv(file_path)

# 提取目标车辆（CAV4）的速度与车间距，以及前车速度
velocity = df["velocity_4"].values
spacing = df["spacing_4"].values
v_front = df["velocity_3"].values  # CAV4 的前车

# 计算相对速度
v_rel = velocity - v_front
epsilon = 1e-3  # 防止除以零

# Step 1: 先计算 TTC（保留正值，其它设为 inf）
ttc_raw = np.where(v_rel > 0, spacing / (v_rel + epsilon), np.inf)

# Step 2: 去掉 inf
ttc_finite = ttc_raw[np.isfinite(ttc_raw)]

# Step 3: 去掉负值
ttc_valid = ttc_finite[ttc_finite >= 0]

# Step 4: 裁剪至最大值 10
TTC_THRESHOLD = 10.0
ttc_clipped = np.clip(ttc_valid, None, TTC_THRESHOLD)

# 安全性指标：平均 TTC
ttc_mean = np.mean(ttc_clipped)
# 稳定性指标：速度标准差
velocity_std = np.std(velocity)

# 平稳性指标：速度方差
velocity_var = np.var(velocity)

# 效率指标：平均速度
velocity_avg = np.mean(velocity)

# 输出结果
print("Average TTC (clipped at 10s): {:.2f}".format(ttc_mean))
print("Velocity Standard Deviation: {:.2f}".format(velocity_std))
#print("Velocity Variance: {:.2f}".format(velocity_var))
print("Average Speed: {:.2f}".format(velocity_avg))
