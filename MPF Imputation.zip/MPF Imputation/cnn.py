import numpy as np
import pandas as pd
import joblib
from tensorflow.keras.models import load_model
from tensorflow.keras.layers import Input, ConvLSTM2D, Conv2D, Flatten, Dense, Dropout, BatchNormalization, Concatenate, Lambda
from sklearn.metrics import mean_squared_error
from cnntrain import improved_impute

# ========== 全局可调参数 ==========
IMPUTE_WINDOW_SIZE = 5       # 插值窗口大小（原hardcode的5）
T = 5
SMOOTHING_WINDOW = 3         # 平滑窗口大小（原hardcode的3） 
DEFAULT_SPEED = 20.0         # 默认速度值（原hardcode的20.0）
DEFAULT_SPACING = 20.0       # 默认间距值（原hardcode的20.0）
MISSING_RATE = 0.60          # 缺失率(randomly)
# ================================
num_front_vehicles = 4

model = load_model("cnn_model_with_mask.keras")
scaler = joblib.load("cnn_scaler.pkl")
label_scaler = joblib.load("cnn_label_scaler.pkl")

df = pd.read_csv("mpf_simulation_output.csv")
velocity = df[[f"velocity_{i}" for i in range(5)]].values
spacing = df[[f"spacing_{i}" for i in range(5)]].values
target_velocity = df["velocity_4"].values
target_spacing = df["spacing_4"].values

# ========== 缺失采样规则（成对缺失） ==========
def simulate_missing_front_indices(rate=MISSING_RATE, num_vehicles=4, total_frames=1000, T=5):
    missing_dict = {}
    for i in range(num_vehicles):
        num_samples = total_frames - T
        num_missing = int(rate * num_samples)
        missing_indices = np.random.choice(np.arange(T, total_frames), size=num_missing, replace=False)
        missing_dict[i] = missing_indices
    return missing_dict

def apply_missing_by_indices(data, missing_dict):
    data_missing = data.copy()
    mask = ~np.isnan(data_missing)
    for i, indices in missing_dict.items():
        for t in indices:
            data_missing[t, i] = np.nan
            mask[t, i] = False
    return data_missing, mask

missing_dict = simulate_missing_front_indices(rate=MISSING_RATE, num_vehicles=num_front_vehicles, total_frames=len(df), T=T)
velocity_missing, mask_v = apply_missing_by_indices(velocity, missing_dict)
spacing_missing, mask_s = apply_missing_by_indices(spacing, missing_dict)

def apply_smoothing(data, window_size=SMOOTHING_WINDOW):
    """应用滑动平均平滑"""
    smoothed = data.copy()
    for i in range(data.shape[1]):
        for j in range(data.shape[2]):
            series = data[:, i, j]
            smoothed[:, i, j] = np.convolve(
                series, 
                np.ones(window_size)/window_size, 
                mode='same'
            )
    return smoothed

# 在补全后调用
velocity_imputed = np.stack([velocity_missing, spacing_missing], axis=-1)
velocity_imputed = apply_smoothing(velocity_imputed, window_size=SMOOTHING_WINDOW)
spacing_imputed = velocity_imputed[:, :, 1]
velocity_imputed = velocity_imputed[:, :, 0]

pred_velocity = []
pred_spacing = []

velocity_filled = velocity_missing.copy()
spacing_filled = spacing_missing.copy()

for t in range(T, len(velocity_missing)):
    for j in range(num_front_vehicles):
        hist_vel = [velocity_filled[t - k - 1, j] for k in range(min(T, t))]  # 向前T帧
        hist_spc = [spacing_filled[t - k - 1, j] for k in range(min(T, t))]

        velocity_filled[t, j] = improved_impute(velocity_missing[t, j], hist_vel, velocity_filled[t], 0)
        spacing_filled[t, j] = improved_impute(spacing_missing[t, j], hist_spc, spacing_filled[t], 1)

# ====== Step 1: 初始化保存预测结果 ======
pred_velocity = np.full(len(df), np.nan)
pred_spacing = np.full(len(df), np.nan)

# ====== Step 2: 对每个时间步预测 CAV4 状态 ======
for i in range(T, len(velocity_missing)):
    x, m = [], []
    for t in range(T):
        row_idx = i - T + t + 1
        x_t, m_t = [], []
        for j in range(num_front_vehicles):
            x_t.append([velocity_filled[row_idx, j], spacing_filled[row_idx, j]])
            m_t.append([
                0.0 if np.isnan(velocity_missing[row_idx, j]) else 1.0,
                0.0 if np.isnan(spacing_missing[row_idx, j]) else 1.0
            ])
        x.append(x_t)
        m.append(m_t)

    x = np.array(x)
    m = np.array(m)

    # 标准化输入
    x_scaled = scaler.transform(x.reshape(1, -1)).reshape(1, T, 4, 2)
    m_scaled = m.reshape(1, T, 4, 2)

    # 预测
    y_pred = model.predict([x_scaled, m_scaled], verbose=0)[0]
    y_pred = label_scaler.inverse_transform(y_pred.reshape(1, -1)).reshape(2)

    # 只赋值 CAV4 的状态（index = 4）
    velocity_filled[i, 4] = y_pred[0]
    spacing_filled[i, 4] = y_pred[1]
    pred_velocity[i] = y_pred[0]
    pred_spacing[i] = y_pred[1]

# ====== Step 3: 写入输出文件 ======
df_out = df.copy()
for i in range(5):
    df_out[f"velocity_{i}"] = velocity_filled[:, i]
    df_out[f"spacing_{i}"] = spacing_filled[:, i]

df_out.to_csv("cnn_60%missing_complete.csv", index=False)
print("✅ Saved to cnn_60%missing_complete.csv")

# ====== Step 4: 误差评估（仅对发生变化的帧） ======
def compute_mse_filtered(y_true, y_pred, mask):
    return mean_squared_error(y_true[mask], y_pred[mask])

def compute_mae_filtered(y_true, y_pred, mask):
    return np.mean(np.abs(y_true[mask] - y_pred[mask]))

target_velocity = df["velocity_4"].values
target_spacing = df["spacing_4"].values

changed_mask_velocity = ~np.isnan(pred_velocity[T:]) & (target_velocity[T:] != pred_velocity[T:])
changed_mask_spacing = ~np.isnan(pred_spacing[T:]) & (target_spacing[T:] != pred_spacing[T:])

print("===== CNN评估指标（CAV4状态变动帧）=====")
print(f"Velocity MSE (changed only): {compute_mse_filtered(target_velocity[T:], pred_velocity[T:], changed_mask_velocity):.4f}")
print(f"Spacing  MSE (changed only): {compute_mse_filtered(target_spacing[T:], pred_spacing[T:], changed_mask_spacing):.4f}")
print(f"Velocity MAE (changed only): {compute_mae_filtered(target_velocity[T:], pred_velocity[T:], changed_mask_velocity):.4f}")
print(f"Spacing  MAE (changed only): {compute_mae_filtered(target_spacing[T:], pred_spacing[T:], changed_mask_spacing):.4f}")
