from typing import Tuple
import numpy as np
import gym
from gym import spaces
import pandas as pd
# 设定全局头车扰动（正弦波）
SIN_FREQ = 0.01  # 频率
SIN_AMPLITUDE = 0.1  # 最大振幅
MAX_STEPS = 1500  # 设定最大仿真步数
GLOBAL_DISTURBANCE = SIN_AMPLITUDE * np.sin(2 * np.pi * SIN_FREQ * np.arange(MAX_STEPS))

class MPFPlatoonEnv(gym.Env):
    def __init__(self, num_vehicles=5, num_predecessors=4, cav_index=4, dt=0.1, select_scenario=0):
        
        if isinstance(cav_index, int):
            self.cav_index = [cav_index]
        else:
            self.cav_index = cav_index

        super().__init__()
                
        # 基本参数
        self.num_vehicles = num_vehicles
        self.num_predecessors = num_predecessors
        self.select_scenario = select_scenario
        self.dt = dt
        self.max_steps = 1000
        self.steps = 0

        # 状态变量
        self.position = np.zeros(num_vehicles)
        self.velocity = np.zeros(num_vehicles)
        self.acceleration = np.zeros(num_vehicles)
        self.spacing = np.zeros(num_vehicles)

        # 参数
        self.v0 = 20.0
        self.s0 = 20.0
        self.a_max = 3.0
        self.a_min = -3.0
        self.alpha = 0.6
        self.beta = 0.9
        self.s_go = 35
        self.s_st = 5
        self.v_max = 30.0
        self.v_min = 10.0

        # 动作空间（控制CAV）
        self.action_space = spaces.Box(
            low=np.array([-3.0]),
            high=np.array([3.0]),
            dtype=np.float32
        )

        # 观测空间 = (num_predecessors + 1) × 2（速度+间距）
        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(2 * (self.num_predecessors + 1),),
            dtype=np.float32
        )

        # 头车抖动参数
        if self.select_scenario == 0:
            self.disturbance_amplitude = 5  # 抖动幅度
        else:
            # using NGSIM for the head vehicle velocity
            self.car_following_data = pd.read_csv('NGSIM/useful_traj_pairs.csv')
            # 筛掉长度小于1000的轨迹（对于每个vehicle，使用后groupby），没有length这个列，使用groupby的size
            self.car_following_data = self.car_following_data.groupby('Vehicle_ID').filter(lambda x: len(x) > 1000)
            self.vehicle_id = self.car_following_data['Vehicle_ID'].unique()
            self.NGSIM_episodes = len(self.vehicle_id)

        self.episiode_id = 0

    def reset(self):
        self.steps = 0

        # 重置状态
        self.velocity.fill(self.v0)
        self.acceleration.fill(0.0)
        for i in range(self.num_vehicles):
            self.position[i] = (self.num_vehicles - i - 1) * self.s0

        for i in range(1, self.num_vehicles):
            self.spacing[i] = max(self.position[i - 1] - self.position[i], self.s_st)
        self.spacing[0] = self.s0  # 为了统一格式，手动赋值

        if self.select_scenario == 1:
            self.veh_velocity_traj = self.car_following_data[self.car_following_data['Vehicle_ID'] == self.vehicle_id[self.episiode_id]]['v_Vel'].values
            self.length_veh_velocity_traj = len(self.veh_velocity_traj)

        return self.get_obs()

    def step(self, action: np.ndarray):
        cav = self.cav_index[0]
        self.acceleration[cav] = np.clip(action[0], self.a_min, self.a_max)

        if self.select_scenario == 0:
            v_target = self.v0  # 恒定期望速度
            a_random = self.disturbance_amplitude * (2 * np.random.random() - 1)
            self.acceleration[0] = 0.1 * (v_target - self.velocity[0]) + a_random

            # 加入正弦扰动叠加
            self.velocity[0] += GLOBAL_DISTURBANCE[self.steps]


        else:
            self.velocity[0] = self.veh_velocity_traj[self.steps]

        # 更新头车状态（车辆0）
        self.velocity[0] += self.acceleration[0] * self.dt
        self.velocity[0] = np.clip(self.velocity[0], self.v_min, self.v_max)
        self.position[0] += self.velocity[0] * self.dt

        self._update_vehicles()  # 调用统一更新逻辑

        for i in range(1, self.num_vehicles):
            self.spacing[i] = max(self.position[i - 1] - self.position[i], 5)

        self.steps += 1
        done = (self.steps >= self.max_steps if self.select_scenario == 0 else self.steps >= (self.length_veh_velocity_traj - 1))
        obs = self.get_obs()
        reward = self._get_reward()
        return obs, reward, done, {}

    def _update_vehicles(self):
        # 更新所有车辆状态
        for i in range(self.num_vehicles - 1, 0, -1):
            dv = self.velocity[i-1] - self.velocity[i]
            if i not in self.cav_index:
                # FVD update
                # calculate the desired acceleration
                cal_D = self.spacing[i]
                if cal_D > self.s_go:
                    cal_D = self.s_go
                elif cal_D < self.s_st:
                    cal_D = self.s_st

                self.acceleration[i] = self.alpha * (self.v_max/2*(1-np.cos(np.pi*(cal_D-self.s_st)/(self.s_go-self.s_st))) - self.velocity[i]) + self.beta * dv
                if self.acceleration[i] > self.a_max:
                    self.acceleration[i] = self.a_max
                elif self.acceleration[i] < self.a_min:
                    self.acceleration[i] = self.a_min

            
            # 更新速度和位置
            self.velocity[i] += self.acceleration[i] * self.dt
            self.velocity[i] = np.clip(self.velocity[i], self.v_min, self.v_max)  # 新增限速
            self.position[i] += self.velocity[i] * self.dt
            self.spacing[i] = max(self.position[i - 1] - self.position[i], self.s_st)  # 每次用位置差更新间距

    def get_obs(self):
        obs_all = []
        for cav in self.cav_index:
            obs_v = []
            obs_s = []
            for i in range(self.num_predecessors, 0, -1):
                idx = cav - i
                if idx >= 0:
                    obs_v.append(self.velocity[idx])
                    obs_s.append(self.spacing[idx])
                else:
                    obs_v.append(0.0)
                    obs_s.append(self.s0)
            obs_v.append(self.velocity[cav])
            obs_s.append(self.spacing[cav])
            obs_all.append(np.array(obs_v + obs_s, dtype=np.float32))
        return obs_all  # List of np.array

    
    def get_states(self):
        return np.concatenate([
            self.velocity,
            self.spacing
        ]).astype(np.float32)
    
    def get_position(self):
        return self.position.astype(np.float32)

    def _reward_safety(self):
        total = 0
        for cav in self.cav_index:
            rel_v = self.velocity[cav - 1] - self.velocity[cav]
            if rel_v <= 0:
                ttc = float('inf')  # 避免碰撞风险，或后车更快但无风险
            else:
                ttc = max(self.spacing[cav] / (rel_v + 1e-6), 0.0)  # 设置 TTC 最小为 0

            # 只对 0 < TTC < 4 有惩罚项，其余不计或设为奖励/0
            if 0 < ttc < 4:
                total += np.log(ttc / 4)
        return total / len(self.cav_index)

    def _reward_efficiency(self):
        reward = 0
        for i in self.cav_index:
            if self.spacing[i] / (self.velocity[i] + 1e-6) > 2.5:
                reward -= 2.5
        return reward

    def _reward_stability(self):
        reward = 0
        for cav in self.cav_index:
            if cav == 0:
                continue
            decay = 0.5  # 可改为权重函数
            reward -= decay * (self.velocity[cav] - self.velocity[cav - 1]) ** 2
        return reward

    def _reward_spacing_equilibrium(self):
        reward = 0
        for cav in self.cav_index:
            reward -= 0.3 * (self.spacing[cav] - self.s0) ** 2
        return reward

    def _get_reward(self):
        w = [0.3, 0.3, 0.2, 0.2]
        safety = self._reward_safety()
        efficiency = self._reward_efficiency()
        stability = self._reward_stability()
        spacing_equilibrium = self._reward_spacing_equilibrium()
    
        return (w[0] * safety + w[1] * efficiency + w[2] * stability + w[3] * spacing_equilibrium)

# 简单 PID 控制（比例 + 积分）
class PIDController:
    def __init__(self, Kp=0.4, Ki=0.02, Kd=0.1, dv_gain=0.4):
        self.Kp = Kp
        self.Ki = Ki
        self.Kd = Kd
        self.dv_gain = dv_gain  # ✅ 添加为类属性
        self.integral = 0
        self.prev_error = 0

    def get_action(self, spacing, v_front, v_self):
        target_spacing = 20 + 0.5 * (v_front - v_self)
        error = spacing - target_spacing
        self.integral += error
        derivative = error - self.prev_error
        self.prev_error = error

        dv = v_front - v_self
        a = (
            self.Kp * error +
            self.Ki * self.integral +
            self.Kd * derivative +
            self.dv_gain * dv   # ✅ 使用 self.dv_gain
        )
        return np.clip([a], -3, 3)

# 假设 env 是你初始化后的环境对象
env = MPFPlatoonEnv()
env.reset()

velocity_list = []
spacing_list = []
position_list = []
reward_list = []

pid = PIDController()

for _ in range(500):
    action = pid.get_action(
        spacing=env.spacing[2],
        v_front=env.velocity[1],
        v_self=env.velocity[2]
    )
    obs, reward, done, _ = env.step(action)

    velocity_list.append(env.velocity.copy())
    spacing_list.append(env.spacing.copy())
    position_list.append(env.position.copy())
    reward_list.append(reward)

    if done:
        break

df_reward = pd.DataFrame({"reward": reward_list})

# 构建 DataFrame（列：车0、车1、车2...）
df_velocity = pd.DataFrame(velocity_list, columns=[f"velocity_{i}" for i in range(env.num_vehicles)])
df_spacing = pd.DataFrame(spacing_list, columns=[f"spacing_{i}" for i in range(env.num_vehicles)])
df_position = pd.DataFrame(position_list, columns=[f"position_{i}" for i in range(env.num_vehicles)])

# 合并所有状态数据
df = pd.concat([df_velocity, df_spacing, df_position], axis=1)

# 假设你已经构建好了 df（包含 step, velocity, spacing 等列）
df.insert(0, "step", range(len(df)))  # 👈 添加 step 序号列

df.columns = [
    "step",
    "velocity_0", "velocity_1", "velocity_2", "velocity_3", "velocity_4",
    "spacing_0", "spacing_1", "spacing_2", "spacing_3", "spacing_4",
    "position_0", "position_1", "position_2", "position_3", "position_4",
]

df.to_excel("C:/Users/10437/Desktop/mpf_simulation_output.xlsx", index=False)