import time, os, joblib, numpy as np, pandas as pd
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.layers import Lambda
from tensorflow.keras.utils import register_keras_serializable
from keras import config as keras_config
keras_config.enable_unsafe_deserialization()  # 在程序开头调用一次

# ---------- 环境可选：固定显卡 & 关闭eager日志 ----------
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "0")
tf.get_logger().setLevel("ERROR")

# ---------- 载入数据 ----------
CSV = "mpf_simulation_output.csv"
df = pd.read_csv(CSV)

# 构造一个帮助函数：切 T 帧窗口
def make_windows(df, T, num_front=4):
    X_list, M_list = [], []
    for i in range(T, len(df)):
        x_t, m_t = [], []
        for t in range(T):
            row = i - T + t + 1
            frame_x, frame_m = [], []
            for j in range(num_front):
                v = df[f"velocity_{j}"].iloc[row]
                s = df[f"spacing_{j}"].iloc[row]
                frame_x.append([v, s])
                frame_m.append([0.0 if pd.isna(v) else 1.0, 0.0 if pd.isna(s) else 1.0])
            x_t.append(frame_x)
            m_t.append(frame_m)
        X_list.append(np.array(x_t))
        M_list.append(np.array(m_t))
    X = np.array(X_list)        # [N, T, 4, 2]
    M = np.array(M_list)        # [N, T, 4, 2]
    # 简单兜底：NaN -> 0 （只为计时，实际训练/推理你已有更完善插补）
    X = np.nan_to_num(X, nan=0.0)
    return X, M

# ---------- 统计均值法（NumPy） ----------
def run_baseline_latency(X):
    # 这里模拟 baseline.py 的插补+均值预测核心（只计前向平均），不做磁盘IO
    # 每个样本：对 [T,4,2] 做均值 -> 2 维输出
    start = time.perf_counter()
    out = X.mean(axis=(1,2))    # [N, 2]
    end = time.perf_counter()
    return out, (end - start)

# ---------- CNN-LSTM ----------
CNN_T = 5
cnn_model = load_model("cnn_model_with_mask.keras", compile=False)
cnn_scaler = joblib.load("cnn_scaler.pkl")
cnn_label_scaler = joblib.load("cnn_label_scaler.pkl")
X_cnn, M_cnn = make_windows(df, CNN_T)
# 标准化保持与你训练一致
X_cnn_scaled = cnn_scaler.transform(X_cnn.reshape(len(X_cnn), -1)).reshape(-1, CNN_T, 4, 2)

# ---------- Transformer ----------
@register_keras_serializable()
def get_attention_mask(mask_inputs):
    frame_mask = tf.reduce_all(tf.equal(mask_inputs, 1.0), axis=[2,3])  # [B,T]
    frame_mask = tf.cast(frame_mask, dtype=tf.bool)
    frame_mask = tf.expand_dims(frame_mask, axis=1)  # [B,1,T]
    return tf.logical_and(tf.expand_dims(frame_mask,2), tf.expand_dims(frame_mask,3))

TRANS_T = 10
trans_model = load_model("transformer_model_with_mask.keras",
                         custom_objects={"get_attention_mask": get_attention_mask},
                         compile=False)
trans_scaler = joblib.load("scaler.pkl")
trans_label_scaler = joblib.load("label_scaler.pkl")
X_tr, M_tr = make_windows(df, TRANS_T)
X_tr_scaled = trans_scaler.transform(X_tr.reshape(len(X_tr), -1)).reshape(-1, TRANS_T, 4, 2)

# ---------- 通用计时函数 ----------
def benchmark(model_or_fn, inputs, mask=None, batch_size=32, warmup=10, reps=50):
    import time
    import numpy as np
    # 判断是 Keras 模型还是普通函数
    is_keras_model = hasattr(model_or_fn, "inputs")

    # Keras 模型：读取需要的输入个数；普通函数默认 1 输入
    num_inputs = len(model_or_fn.inputs) if is_keras_model else 1

    def call_batch(bx, bm=None):
        if is_keras_model:
            if num_inputs == 1:
                return model_or_fn(bx, training=False)
            elif num_inputs == 2:
                if bm is None:
                    raise ValueError("该模型需要 mask 作为第二个输入，但 mask=None。")
                return model_or_fn([bx, bm], training=False)
            else:
                raise ValueError(f"暂不支持 {num_inputs} 个输入的模型")
        else:
            # 普通 Python 函数：只传一个 inputs
            return model_or_fn(bx)

    # 预热
    n = len(inputs)
    sl = slice(0, min(batch_size, n))
    _ = call_batch(inputs[sl], mask[sl] if mask is not None else None)

    # 正式计时
    start = time.perf_counter()
    iters = 0
    for i in range(0, n, batch_size):
        sl = slice(i, min(i + batch_size, n))
        _ = call_batch(inputs[sl], mask[sl] if mask is not None else None)
        iters += (sl.stop - sl.start)

    end = time.perf_counter()
    total_time = end - start
    avg_ms_per_sample = (total_time / iters) * 1000.0
    throughput = iters / total_time
    return avg_ms_per_sample, throughput

# ---------- 统计参数量 ----------
def count_params(model):
    try:
        return model.count_params() / 1e6
    except:
        return None

# ---------- 跑基准 ----------
print("== Benchmarking ==")
bl_lat, bl_thr = benchmark(run_baseline_latency, X_cnn)   # 任取一套窗口，只为计时对比
cnn_lat, cnn_thr = benchmark(cnn_model, X_cnn_scaled, mask=M_cnn)
tr_lat, tr_thr   = benchmark(trans_model, X_tr_scaled, mask=M_tr)

print("\nParams (M):")
print(f"  CNN-LSTM:     {count_params(cnn_model):.3f}")
print(f"  Transformer:  {count_params(trans_model):.3f}")

print("\nLatency (ms/sample) and Throughput (samples/s):")
print(f"  Statistical Mean:  {bl_lat:.3f} ms  |  {bl_thr:.0f} samples/s")
print(f"  CNN-LSTM:          {cnn_lat:.3f} ms  |  {cnn_thr:.0f} samples/s")
print(f"  Transformer:       {tr_lat:.3f} ms  |  {tr_thr:.0f} samples/s")

print("\nPaste into Table:")
print("Statistical Mean Imputation & N/A & %.2f & %.0f \\\\" % (bl_lat, bl_thr))
print("CNN-LSTM (mask-aware) & %.2f & %.2f & %.0f \\\\" % (count_params(cnn_model), cnn_lat, cnn_thr))
print("Transformer (mask-aware) & %.2f & %.2f & %.0f \\\\" % (count_params(trans_model), tr_lat, tr_thr))
