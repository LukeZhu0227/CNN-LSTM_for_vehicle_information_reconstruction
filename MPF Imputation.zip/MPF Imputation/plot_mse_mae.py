import matplotlib.pyplot as plt

# 缺失率
missing_rates = [10, 20, 30, 40, 50, 60, 70, 80, 90]

# 从图片中手动提取的数据
velocity_mse = {
    "Statistical Mean": [27.95, 28.77, 31.34, 38.38, 56.45, 91.88, 129.01, 204.38, 295.05],
    "Transformer": [8.01, 17.18, 25.47, 30.01, 32.79, 33.52, 33.14, 35.31, 34.01],
    "CNN-LSTM": [1.18, 1.61, 2.34, 3.37, 4.39, 7.41, 11.38, 18.79, 32.98]
}

spacing_mse = {
    "Statistical Mean": [114.89, 117.69, 122.98, 136.87, 146.07, 203.21, 265.98, 343.39, 517.81],
    "Transformer": [20.88, 53.23, 94.06, 140.06, 196.50, 306.87, 520.03, 759.07, 1197.51],
    "CNN-LSTM": [8.26, 13.29, 15.27, 23.26, 33.73, 58.11, 77.14, 138.33, 177.75]
}

velocity_mae = {
    "Statistical Mean": [4.56, 4.59, 4.71, 4.96, 5.64, 6.95, 8.47, 11.26, 14.73],
    "Transformer": [1.98, 3.11, 4.01, 4.52, 4.69, 4.86, 4.80, 5.12, 4.96],
    "CNN-LSTM": [0.79, 0.93, 1.12, 1.30, 1.54, 2.09, 2.54, 3.43, 4.59]
}

spacing_mae = {
    "Statistical Mean": [9.31, 9.36, 9.48, 9.80, 10.09, 11.44, 13.12, 15.15, 19.46],
    "Transformer": [3.26, 5.21, 7.14, 8.77, 10.05, 12.49, 16.97, 22.44, 29.79],
    "CNN-LSTM": [1.84, 2.38, 2.54, 3.01, 3.83, 4.96, 6.18, 8.16, 10.52]
}

# 定义颜色和样式
color_map = {
    "CNN-LSTM": "blue",
    "Transformer": "green",
    "Statistical Mean": "orange"
}
linestyle_map = {
    "CNN-LSTM": "-",
    "Transformer": "-.",
    "Statistical Mean": "--"
}
marker_map = {
    "CNN-LSTM": "^",
    "Transformer": "s",
    "Statistical Mean": "o"
}

# 函数：绘图并保存
def plot_metric(data_dict, ylabel, title, filename):
    plt.figure(figsize=(8, 5))
    for model in data_dict:
        plt.plot(
            missing_rates,
            data_dict[model],
            label=model,
            color=color_map[model],
            linestyle=linestyle_map[model],
            marker=marker_map[model]
        )
    plt.xlabel("Missing Rate (%)")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()
    plt.close()

# 批量生成四张图
plot_metric(velocity_mse, "Velocity MSE", "Velocity MSE under Different Missing Rates", "velocity_mse")
plot_metric(spacing_mse, "Spacing MSE", "Spacing MSE under Different Missing Rates", "spacing_mse")
plot_metric(velocity_mae, "Velocity MAE", "Velocity MAE under Different Missing Rates", "velocity_mae")
plot_metric(spacing_mae, "Spacing MAE", "Spacing MAE under Different Missing Rates", "spacing_mae")
