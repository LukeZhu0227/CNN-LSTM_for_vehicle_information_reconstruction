import numpy as np
import pandas as pd
import joblib
import tensorflow as tf
from keras import config
from tensorflow.keras.models import load_model
from tensorflow.keras.utils import register_keras_serializable
from sklearn.metrics import mean_squared_error
from tensorflow.keras.layers import Lambda

# 参数
T = 10
num_front_vehicles = 4
channels = 2

@register_keras_serializable()
def get_attention_mask(mask_inputs):
    frame_mask = tf.reduce_all(tf.equal(mask_inputs, 1.0), axis=[2, 3])  # [B, T]
    frame_mask = tf.cast(frame_mask, dtype=tf.bool)
    frame_mask = tf.expand_dims(frame_mask, axis=1)  # [B, 1, T]
    return tf.logical_and(
        tf.expand_dims(frame_mask, axis=2),  # [B, 1, 1, T]
        tf.expand_dims(frame_mask, axis=3)   # [B, 1, T, 1]
    )

config.enable_unsafe_deserialization()

# ✅ 注册后加载模型
model = load_model("transformer_model_with_mask.keras", custom_objects={"get_attention_mask": get_attention_mask})
scaler = joblib.load("scaler.pkl")
label_scaler = joblib.load("label_scaler.pkl")

# ========== 读取数据 ==========
df = pd.read_csv("mpf_simulation_output.csv")
velocity = df[[f"velocity_{i}" for i in range(5)]].values
spacing = df[[f"spacing_{i}" for i in range(5)]].values

# ========== 缺失模拟（仅前4辆车） ==========
def simulate_missing_front(data, rate=0.90):
    data_missing = data.copy()
    mask = ~np.isnan(data_missing)
    for i in range(num_front_vehicles):
        for t in range(T, len(data)):
            if np.random.rand() < rate:
                data_missing[t, i] = np.nan
                mask[t, i] = False
    return data_missing, mask

# ========== 补全NaN的兜底函数 ==========
def impute(x, m):
    x = x.copy()
    for i in range(x.shape[1]):
        for j in range(x.shape[2]):
            for t in range(x.shape[0]):
                if m[t, i, j] == 0:
                    peer_vals = x[t, :, j]
                    peer_vals = peer_vals[~np.isnan(peer_vals)]
                    x[t, i, j] = np.mean(peer_vals) if len(peer_vals) > 0 else 0.0
    return x

# ========== Transformer补全过程 ==========
def transformer_fill_front(velocity_missing, spacing_missing, mask_v, mask_s):
    velocity_interp = velocity_missing.copy()
    spacing_interp = spacing_missing.copy()

    for i in range(T, len(velocity_missing)):
        x = []
        m = []
        for t in range(T):
            vel_t = velocity_missing[i - T + t + 1]
            spc_t = spacing_missing[i - T + t + 1]
            x_t, m_t = [], []
            for j in range(num_front_vehicles):
                x_t.append([vel_t[j], spc_t[j]])
                m_t.append([
                    0.0 if np.isnan(vel_t[j]) else 1.0,
                    0.0 if np.isnan(spc_t[j]) else 1.0,
                ])
            x.append(x_t)
            m.append(m_t)

        x = np.array(x)     # [T, 4, 2]
        m = np.array(m)     # [T, 4, 2]
        x = impute(x, m)    # 兜底补全
        x_scaled = scaler.transform(x.reshape(1, -1)).reshape(1, T, 4, 2)
        m_scaled = m.reshape(1, T, 4, 2)

        y_pred = model.predict([x_scaled, m_scaled], verbose=0)[0]
        y_pred = label_scaler.inverse_transform(y_pred.reshape(1, -1)).reshape(2)

        # 预测的是目标车辆（车辆4）的值，作为结果直接返回或记录
        velocity_interp[i, 4] = y_pred[0]
        spacing_interp[i, 4] = y_pred[1]

        # 补全前4车原始缺失位置（使用 impute 后的 x）
        for j in range(num_front_vehicles):
            if np.isnan(velocity_interp[i, j]):
                velocity_interp[i, j] = x[-1, j, 0]  # x[-1] 是当前帧 t=T-1
            if np.isnan(spacing_interp[i, j]):
                spacing_interp[i, j] = x[-1, j, 1]

    return velocity_interp, spacing_interp

# ========== 执行补全过程 ==========
velocity_missing, mask_v = simulate_missing_front(velocity.copy())
spacing_missing, mask_s = simulate_missing_front(spacing.copy())
velocity_interp, spacing_interp = transformer_fill_front(velocity_missing, spacing_missing, mask_v, mask_s)

# ========== 存储结果 ==========
df_interp = df.copy()
for i in range(5):
    df_interp[f"velocity_{i}"] = velocity_interp[:, i]
    df_interp[f"spacing_{i}"] = spacing_interp[:, i]
df_interp.to_csv("transformer_90%missing_complete.csv", index=False)

# ========== 评估目标车辆 CAV4（第5辆车）状态，仅针对发生变动的帧 ==========
def compute_mse_filtered(y_true, y_pred, mask):
    return mean_squared_error(y_true[mask], y_pred[mask])

def compute_mae_filtered(y_true, y_pred, mask):
    return np.mean(np.abs(y_true[mask] - y_pred[mask]))

# 原始 CAV4 数据（速度和间距）
target_velocity = velocity[:, 4]
target_spacing = spacing[:, 4]

# 替换后 CAV4 数据
pred_velocity = velocity_interp[:, 4]
pred_spacing = spacing_interp[:, 4]

# 从第T帧开始，找出发生变化的帧
changed_mask_velocity = target_velocity[T:] != pred_velocity[T:]
changed_mask_spacing = target_spacing[T:] != pred_spacing[T:]

print("===== Transformer评估指标（CAV4状态变动帧） =====")
print(f"Velocity MSE (changed only): {compute_mse_filtered(target_velocity[T:], pred_velocity[T:], changed_mask_velocity):.4f}")
print(f"Spacing  MSE (changed only): {compute_mse_filtered(target_spacing[T:], pred_spacing[T:], changed_mask_spacing):.4f}")
print(f"Velocity MAE (changed only): {compute_mae_filtered(target_velocity[T:], pred_velocity[T:], changed_mask_velocity):.4f}")
print(f"Spacing  MAE (changed only): {compute_mae_filtered(target_spacing[T:], pred_spacing[T:], changed_mask_spacing):.4f}")
