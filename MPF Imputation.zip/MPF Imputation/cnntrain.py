import tensorflow as tf
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.layers import Input, ConvLSTM2D, Conv2D, Flatten, Dense, Dropout, BatchNormalization, Concatenate, Lambda, Reshape
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import pandas as pd
import numpy as np
import joblib
IMPUTE_WINDOW_SIZE = 5       # 插值窗口大小（原hardcode的5）
T = 5
SMOOTHING_WINDOW = 3         # 平滑窗口大小（原hardcode的3） 
DEFAULT_SPEED = 20.0         # 默认速度值（原hardcode的20.0）
DEFAULT_SPACING = 20.0       # 默认间距值（原hardcode的10.0）

def improved_impute(value, history, peer_values, feature_index):
    """
    对单个缺失值进行补全
    :param value: 当前值，float，可能为 NaN
    :param history: 历史值（list of float），可能包含 NaN
    :param peer_values: 同时刻同类车辆值（list of float），可能包含 NaN
    :param feature_index: 0 表示速度，1 表示车距
    :return: 补全后的值（float）
    """
    if not pd.isna(value):
        return value  # 无需补全

    # 全局默认值
    default_val = DEFAULT_SPEED if feature_index == 0 else DEFAULT_SPACING

    history = np.array(history) if history is not None else np.array([])
    peer_values = np.array(peer_values) if peer_values is not None else np.array([])

    # 1. 历史加权平均
    valid_hist = history[~np.isnan(history)]
    if len(valid_hist) > 0:
        weights = np.linspace(1, 2, len(valid_hist))  # 越近时间权重越高
        return np.average(valid_hist, weights=weights[:len(valid_hist)])

    # 2. 同时刻同类车辆的中位数
    valid_peers = peer_values[~np.isnan(peer_values)]
    if len(valid_peers) >= 2:
        return np.median(valid_peers)

    # 3. 保底方案：默认值 + 随机微扰
    noise = np.random.normal(0, 0.1) if feature_index == 0 else np.random.normal(0, 0.5)
    return default_val + noise

def load_data_with_mask(file_path):
    data = pd.read_csv(file_path)
    # 移除初始的ffill/bfill，保留原始缺失模式
    T = 5
    num_preceding = 4
    channels = 2

    features, masks, labels = [], [], []

    for i in range(T, len(data)):
        vel_hist = []
        mask_hist = []
        prev_vels = []  # 保存历史速度用于插值
        prev_spcs = []  # 保存历史间距用于插值

        for t in range(T):
            row_idx = i - T + t
            current_vels, current_masks = [], []

            peer_vels = [data[f'velocity_{j}'].iloc[row_idx] for j in range(4)]
            peer_spcs = [data[f'spacing_{j}'].iloc[row_idx] for j in range(4)]

            for j in range(4):
                vel = peer_vels[j]
                spc = peer_spcs[j]
                
                # 使用改进的插值方法
                imputed_vel = improved_impute(
                    vel, 
                    [v[j][0] for v in vel_hist] if vel_hist else None,
                    peer_vels, 0
                )
                imputed_spc = improved_impute(
                    spc,
                    [v[j][1] for v in vel_hist] if vel_hist else None,
                    peer_spcs, 1
                )

                current_vels.append([imputed_vel, imputed_spc])
                current_masks.append([int(pd.isna(vel)), int(pd.isna(spc))])
            
            vel_hist.append(current_vels)
            mask_hist.append(current_masks)
            prev_vels.append([v[0] for v in current_vels])
            prev_spcs.append([v[1] for v in current_vels])

        features.append(vel_hist)
        masks.append(mask_hist)
        labels.append([data["velocity_4"].iloc[i], data["spacing_4"].iloc[i]])

    features = np.array(features)
    masks = np.array(masks)
    labels = np.array(labels)

    scaler = StandardScaler()
    features = features.reshape(features.shape[0], -1)
    features = scaler.fit_transform(features)
    features = features.reshape(-1, T, num_preceding, channels)

    label_scaler = StandardScaler()
    labels = label_scaler.fit_transform(labels)

    return features, masks, labels, scaler, label_scaler

def build_cnn_model_with_mask(input_shape):
    """
    构建带掩码输入的 ConvLSTM 模型。
    input_shape: (T, 4, 2)
    """
    # 输入定义
    input_data = Input(shape=input_shape)    # [T, 4, 2]
    input_mask = Input(shape=input_shape)

    x = Reshape((*input_shape, 1))(input_data)
    m = Reshape((*input_shape, 1))(input_mask)

    # 双通道 ConvLSTM
    x = ConvLSTM2D(filters=64, kernel_size=(2,2), padding='same',
                   activation='relu', return_sequences=False)(x)
    m = ConvLSTM2D(filters=64, kernel_size=(2,2), padding='same',
                   activation='relu', return_sequences=False)(m)

    # 融合特征
    merged = Concatenate()([x, m])
    merged = Flatten()(merged)
    merged = Dense(64, activation='relu')(merged)
    merged = Dropout(0.2)(merged)
    merged = Dense(32, activation='relu')(merged)
    output = Dense(2)(merged)

    model = Model(inputs=[input_data, input_mask], outputs=output)
    return model

def train_and_save_model_with_mask(file_path):
    features, masks, labels, scaler, label_scaler = load_data_with_mask(file_path)
    X_train, X_test, mask_train, mask_test, y_train, y_test = train_test_split(
        features, masks, labels, test_size=0.2, random_state=42
    )

    model = build_cnn_model_with_mask(input_shape=(features.shape[1], features.shape[2], features.shape[3]))
    
    model.compile(
        optimizer='adam',
        loss='mse',
        metrics=['mae']
    )

    # 设置回调函数
    callbacks = [
        EarlyStopping(
            monitor='val_loss',     # 监控验证集损失
            patience=10,            # 10个epoch没有改善就停止
            restore_best_weights=True,  # 恢复最佳权重
            verbose=1
        ),
        ModelCheckpoint(
            'best_model.keras',    # 保存路径
            monitor='val_loss',     # 监控指标
            save_best_only=True,    # 只保存最佳模型
            mode='min',             # 最小化监控指标
            verbose=1
        )
    ]

    history = model.fit(
        [X_train, mask_train], y_train,
        epochs=100, 
        batch_size=32,
        validation_split=0.1,
        callbacks=callbacks,        # 添加回调
        verbose=1
    )

    # 加载最佳模型（如果使用了EarlyStopping）
    try:
        model = load_model('best_model.keras')
        print("Loaded best model from checkpoint")
    except:
        print("Using last trained model")

    y_pred = model.predict([X_test, mask_test])
    y_pred = label_scaler.inverse_transform(y_pred)
    y_test = label_scaler.inverse_transform(y_test)

    mse = np.mean((y_test - y_pred) ** 2)
    print(f"Mean Squared Error: {mse}")

    # 保存最终模型（可选，如果更信任完整训练）
    model.save("cnn_model_with_mask.keras")
    joblib.dump(scaler, "cnn_scaler.pkl")
    joblib.dump(label_scaler, "cnn_label_scaler.pkl")
    print("Model and scaler saved successfully!")

if __name__ == "__main__":
    file_path = "mpf_simulation_output.csv"
    train_and_save_model_with_mask(file_path)
