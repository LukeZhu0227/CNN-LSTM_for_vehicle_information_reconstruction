import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Dropout, LayerNormalization, MultiHeadAttention, Flatten, Concatenate, Add, GlobalAveragePooling1D, Reshape
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.layers import Lambda
from tensorflow.keras.callbacks import EarlyStopping
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import joblib

def load_data_with_mask(file_path):
    data = pd.read_csv(file_path)
    data.ffill(inplace=True)
    data.bfill(inplace=True)

    T = 10
    front_vehicles = [0, 1, 2, 3]
    channels = 2
    features, labels, masks = [], [], []

    def impute(curr, ffill, peer):
        if not pd.isna(curr):
            return curr
        candidate_ffill = ffill if (ffill is not None and not pd.isna(ffill)) else None
        candidate_peer = peer if (peer is not None and not pd.isna(peer)) else None
        if candidate_ffill is not None and candidate_peer is not None:
            return (candidate_ffill + candidate_peer) / 2.0
        elif candidate_ffill is not None:
            return candidate_ffill
        elif candidate_peer is not None:
            return candidate_peer
        else:
            return 0

    for i in range(T, len(data)):
        velocity_history, mask_history = [], []

        # 每辆车都准备两个历史列表
        vel_histories = {vid: [] for vid in front_vehicles}
        spc_histories = {vid: [] for vid in front_vehicles}

        for t in range(T):
            row_idx = i - t
            frame_features = []
            frame_mask = []

            for vid in front_vehicles:
                vel = data.get(f'velocity_{vid}', pd.Series([np.nan]*len(data))).iloc[row_idx]
                spc = data.get(f'spacing_{vid}', pd.Series([np.nan]*len(data))).iloc[row_idx]

                # 获取前一帧的前向填充值
                ffill_vel = vel_histories[vid][-1] if vel_histories[vid] else None
                ffill_spc = spc_histories[vid][-1] if spc_histories[vid] else None

                # 获取 peer 车（vid+1）的值作为参考（仅在非最后一辆前车时）
                peer_vid = vid + 1 if vid < 3 else vid - 1
                peer_vel = data.get(f'velocity_{peer_vid}', pd.Series([np.nan]*len(data))).iloc[row_idx]
                peer_spc = data.get(f'spacing_{peer_vid}', pd.Series([np.nan]*len(data))).iloc[row_idx]

                vel_imputed = impute(vel, ffill_vel, peer_vel)
                spc_imputed = impute(spc, ffill_spc, peer_spc)

                vel_histories[vid].append(vel_imputed)
                spc_histories[vid].append(spc_imputed)

                frame_features.append([vel_imputed, spc_imputed])
                frame_mask.append([int(pd.isna(vel)), int(pd.isna(spc))])

            velocity_history.append(frame_features)
            mask_history.append(frame_mask)

        features.append(velocity_history)
        masks.append(mask_history)
        labels.append([
            data['velocity_4'].iloc[i],
            data['spacing_4'].iloc[i]
        ])

    features = np.array(features)
    masks = np.array(masks)
    labels = np.array(labels)

    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler()
    features = features.reshape(features.shape[0], -1)
    features = scaler.fit_transform(features)
    features = features.reshape(-1, T, 4, 2)

    label_scaler = StandardScaler()
    labels = label_scaler.fit_transform(labels)

    return features, masks, labels, scaler, label_scaler

def build_transformer_model(input_shape):
    T, N, C = input_shape  # 输入形状为 (时间步数, 前车数, 通道数)

    feature_inputs = Input(shape=(T, N, C), name='feature_inputs')  # [B, T, 4, 2]
    mask_inputs = Input(shape=(T, N, C), name='mask_inputs')        # [B, T, 4, 2]

    # Attention Mask：只有当前时间帧所有值非缺失，才保留注意力
    def get_attention_mask(mask_inputs):
        frame_mask = tf.reduce_all(tf.equal(mask_inputs, 1.0), axis=[2, 3])  # [B, T]
        frame_mask = tf.cast(frame_mask, dtype=tf.bool)
        frame_mask = tf.expand_dims(frame_mask, axis=1)  # [B, 1, T]
        return tf.logical_and(
            tf.expand_dims(frame_mask, axis=2),  # [B, 1, 1, T]
            tf.expand_dims(frame_mask, axis=3)   # [B, 1, T, 1]
        )

    attention_mask = Lambda(get_attention_mask, name='attention_mask')(mask_inputs)

    # 平铺：将每帧的所有前车信息展平为一维向量（N*C）
    x = Reshape((T, N * C))(feature_inputs)

    # 编码：Dense + Dropout
    x = Dense(256, activation='relu')(x)
    x = Dropout(0.1)(x)

    # 多层编码器结构（Multi-head Attention + FFN + 残差）
    for _ in range(3):
        norm1 = LayerNormalization()(x)
        attn_output = MultiHeadAttention(num_heads=8, key_dim=256)(
            norm1, norm1, attention_mask=attention_mask
        )
        attn_output = Dropout(0.1)(attn_output)
        x = Add()([x, attn_output])

        norm2 = LayerNormalization()(x)
        ff = Dense(512, activation='relu')(norm2)
        ff = Dropout(0.1)(ff)
        ff = Dense(256, activation='relu')(ff)
        x = Add()([x, ff])

    # 输出层：提取最后一帧的隐藏状态作为表示，映射为 CAV4 的预测值
    final_rep = Lambda(lambda x: x[:, -1, :])(x)  # 取最后时间帧
    outputs = Dense(2, name='predictions')(final_rep)  # 输出速度 + 间距

    model = Model(inputs=[feature_inputs, mask_inputs], outputs=outputs)
    model.compile(optimizer='adam', loss='mse')
    return model

def train_and_save_transformer(file_path):
    features, masks, labels, scaler, label_scaler = load_data_with_mask(file_path)

    X_train, X_test, mask_train, mask_test, y_train, y_test = train_test_split(
        features, masks, labels, test_size=0.2, random_state=42
    )

    model = build_transformer_model(input_shape=features.shape[1:])  # 即 (T, 4)

    model.compile(
        optimizer=Adam(learning_rate=1e-3),
        loss='mse',
        metrics=['mae']
    )

    early_stopping = EarlyStopping(
        monitor='val_loss',
        patience=10,
        restore_best_weights=True
    )

    model.fit(
        [X_train, mask_train], y_train,
        epochs=100, batch_size=32,
        validation_split=0.1,
        callbacks=[early_stopping]
    )

    y_pred = model.predict([X_test, mask_test])
    y_pred = label_scaler.inverse_transform(y_pred)
    y_test = label_scaler.inverse_transform(y_test)

    mse = np.mean((y_test - y_pred) ** 2)
    print(f"Mean Squared Error: {mse}")

    model.save("transformer_model_with_mask.keras")
    joblib.dump(scaler, "scaler.pkl")
    joblib.dump(label_scaler, "label_scaler.pkl")
    print("Transformer model and scalers saved successfully!")

# No execution block included, only code definition as requested.

if __name__ == "__main__":
    file_path = "mpf_simulation_output.csv"
    train_and_save_transformer(file_path)